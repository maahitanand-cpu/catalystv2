import CatalystClub from "./CatalystClub";

export default function App() {
  return <CatalystClub />;
}